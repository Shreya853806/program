# Initialize variables
a = 5
b = 10

# Swap the values
a, b = b, a

# Print the swapped values
print("After swapping:")
print("a =", a)
print("b =", b)
