# Input number
n = 5

# Initialize factorial to 1
factorial = 1

# Calculate factorial using a loop
for i in range(1, n + 1):
    factorial *= i

print("Factorial of", n, "is", factorial)
